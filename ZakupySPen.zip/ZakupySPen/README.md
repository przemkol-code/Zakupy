# Zakupy S Pen — Android

Prosta aplikacja zakupowa dla Androida, zaprojektowana pod Samsung Galaxy S22 Ultra i S Pen.

## Funkcje
- pisanie nazwy produktu na obszarze przypominającym papier;
- rozpoznawanie pisma przez Google ML Kit Digital Ink Recognition;
- ręczne dodawanie produktu jako rozwiązanie awaryjne;
- zaznaczanie kupionych pozycji i przekreślanie;
- usuwanie pojedynczych pozycji lub wszystkich kupionych;
- automatyczny zapis lokalny, bez konta i bez serwera.

## Wymagania
- Android Studio (zalecana aktualna stabilna wersja);
- Android SDK 35;
- JDK 17;
- połączenie z internetem przy pierwszym pobieraniu zależności i modelu rozpoznawania.

## Budowanie APK
1. Rozpakuj `ZakupySPen.zip`.
2. Otwórz folder `ZakupySPen` w Android Studio.
3. Poczekaj na Gradle Sync. Jeśli Android Studio poprosi o instalację SDK 35, zaakceptuj.
4. Wybierz **Build > Build APK(s)**.
5. APK debug znajdziesz w `app/build/outputs/apk/debug/app-debug.apk`.

## Instalacja na Samsungu
1. Przenieś `app-debug.apk` na telefon (np. przez kabel USB).
2. Otwórz plik na telefonie i zezwól aplikacji Pliki na instalowanie nieznanych aplikacji, jeśli Android o to poprosi.
3. Zainstaluj i uruchom **Zakupy S Pen**.

## Rozpoznawanie polskiego pisma
Aplikacja prosi ML Kit o model języka `pl` i próbuje pobrać go automatycznie. Dostępność konkretnego identyfikatora języka zależy od wersji biblioteki. Jeżeli polski model nie jest udostępniony przez używaną wersję ML Kit, rozpoznawanie odręczne nie zadziała i aplikacja przejdzie do ręcznego dodawania produktu. Wtedy należy zmienić identyfikator języka na obsługiwany model albo dodać osobny mechanizm OCR/rozpoznawania.

Po pobraniu modelu rozpoznawanie może działać offline. Pierwsze pobranie wymaga internetu.

## Uwagi techniczne
To projekt źródłowy MVP, nie podpisana aplikacja ze sklepu. Warto najpierw zbudować i przetestować go w Android Studio. Rysik jest obsługiwany jako wejście dotykowe; aplikacja zapisuje listy w prywatnych preferencjach aplikacji.
