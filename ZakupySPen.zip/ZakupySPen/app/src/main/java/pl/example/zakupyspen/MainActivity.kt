package pl.example.zakupyspen

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.Gravity
import android.widget.*
import android.content.Context
import com.google.mlkit.vision.digitalink.*
import com.google.mlkit.common.model.*
import java.util.UUID
import org.json.JSONArray
import org.json.JSONObject

private const val PREFS = "zakupy_spen"
private const val KEY_ITEMS = "items"

data class ShoppingItem(val id: String, val text: String, val checked: Boolean)

class MainActivity : Activity() {
    private lateinit var listBox: LinearLayout
    private lateinit var status: TextView
    private lateinit var inkPad: InkPad
    private lateinit var recognizer: DigitalInkRecognizer
    private lateinit var model: DigitalInkRecognitionModel
    private var modelReady = false
    private val items = mutableListOf<ShoppingItem>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val identifier = DigitalInkRecognitionModelIdentifier.fromLanguageTag("pl")
        if (identifier != null) {
            model = DigitalInkRecognitionModel.builder(identifier).build()
            recognizer = DigitalInkRecognition.getClient(
                DigitalInkRecognizerOptions.builder(model).build()
            )
        }
        loadItems()
        buildUi()
        prepareModel()
    }

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(12), dp(18), dp(12))
            setBackgroundColor(Color.rgb(245, 242, 234))
        }
        val title = TextView(this).apply {
            text = "Zakupy"
            textSize = 30f
            setTextColor(Color.rgb(38, 61, 54))
            typeface = android.graphics.Typeface.create("sans-serif-medium", 0)
        }
        root.addView(title)
        val subtitle = TextView(this).apply {
            text = "Lista zakupów • S Pen"
            textSize = 14f
            setTextColor(Color.rgb(100, 108, 101))
            setPadding(0, 0, 0, dp(10))
        }
        root.addView(subtitle)

        val padTitle = TextView(this).apply {
            text = "Napisz nazwę produktu poniżej"
            textSize = 16f
            setTextColor(Color.rgb(38, 61, 54))
            setPadding(0, dp(4), 0, dp(6))
        }
        root.addView(padTitle)
        inkPad = InkPad(this)
        root.addView(inkPad, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(150)
        ).apply { bottomMargin = dp(8) })

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val recognizeButton = Button(this).apply {
            text = "Rozpoznaj i dodaj"
            setOnClickListener { recognizeInk() }
        }
        val clearButton = Button(this).apply {
            text = "Wyczyść"
            setOnClickListener { inkPad.clear() }
        }
        actions.addView(recognizeButton, LinearLayout.LayoutParams(0, dp(48), 1f))
        actions.addView(clearButton, LinearLayout.LayoutParams(dp(110), dp(48)))
        root.addView(actions)

        status = TextView(this).apply {
            text = "Przygotowywanie rozpoznawania pisma…"
            textSize = 13f
            setTextColor(Color.rgb(91, 98, 91))
            setPadding(0, dp(4), 0, dp(8))
        }
        root.addView(status)

        val listHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        listHeader.addView(TextView(this).apply {
            text = "Twoja lista"
            textSize = 21f
            setTextColor(Color.rgb(38, 61, 54))
        }, LinearLayout.LayoutParams(0, dp(42), 1f))
        listHeader.addView(Button(this).apply {
            text = "Usuń kupione"
            setOnClickListener {
                items.removeAll { it.checked }
                saveItems()
                renderItems()
            }
        })
        root.addView(listHeader)

        val scroll = ScrollView(this)
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(listBox)
        root.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        setContentView(root)
        renderItems()
    }

    private fun prepareModel() {
        if (!::model.isInitialized) {
            status.text = "Brak modelu języka polskiego. Możesz dodawać produkty ręcznie."
            return
        }
        val conditions = DownloadConditions.Builder().build()
        RemoteModelManager.getInstance().download(model, conditions)
            .addOnSuccessListener {
                modelReady = true
                status.text = "Rozpoznawanie pisma gotowe."
            }
            .addOnFailureListener {
                status.text = "Nie udało się pobrać modelu. Sprawdź internet; możesz dodać produkt ręcznie."
            }
    }

    private fun recognizeInk() {
        if (inkPad.isEmpty()) {
            manualAdd()
            return
        }
        if (!modelReady || !::recognizer.isInitialized) {
            status.text = "Model nie jest gotowy. Wpisz produkt ręcznie albo spróbuj później."
            manualAdd()
            return
        }
        status.text = "Rozpoznawanie…"
        val ink = inkPad.getInk()
        val context = WritingArea(inkPad.width.toFloat(), inkPad.height.toFloat())
        recognizer.recognize(ink, RecognitionContext.builder()
            .setWritingArea(context)
            .build())
            .addOnSuccessListener { result ->
                val text = result.candidates.firstOrNull()?.text?.trim().orEmpty()
                if (text.isNotBlank()) {
                    addItem(text)
                    inkPad.clear()
                    status.text = "Dodano: $text"
                } else {
                    status.text = "Nie udało się odczytać pisma. Spróbuj ponownie lub wpisz produkt ręcznie."
                    manualAdd()
                }
            }
            .addOnFailureListener {
                status.text = "Błąd rozpoznawania. Możesz wpisać produkt ręcznie."
                manualAdd()
            }
    }

    private fun manualAdd() {
        val input = EditText(this).apply {
            hint = "Np. mleko, chleb, jajka"
            setSingleLine(true)
        }
        AlertDialog.Builder(this)
            .setTitle("Dodaj produkt")
            .setView(input)
            .setNegativeButton("Anuluj", null)
            .setPositiveButton("Dodaj") { _, _ ->
                val text = input.text.toString().trim()
                if (text.isNotEmpty()) addItem(text)
            }.show()
    }

    private fun addItem(text: String) {
        items.add(0, ShoppingItem(UUID.randomUUID().toString(), text, false))
        saveItems()
        renderItems()
    }

    private fun renderItems() {
        if (!::listBox.isInitialized) return
        listBox.removeAllViews()
        if (items.isEmpty()) {
            listBox.addView(TextView(this).apply {
                text = "Lista jest pusta. Napisz pierwszy produkt rysikiem."
                textSize = 15f
                setTextColor(Color.GRAY)
                setPadding(0, dp(12), 0, dp(12))
            })
        }
        items.forEach { item ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(8), dp(4), dp(4), dp(4))
                setBackgroundColor(Color.WHITE)
            }
            val check = CheckBox(this).apply {
                isChecked = item.checked
                buttonTintList = android.content.res.ColorStateList.valueOf(Color.rgb(53, 104, 89))
                setOnCheckedChangeListener { _, checked ->
                    val index = items.indexOfFirst { it.id == item.id }
                    if (index >= 0) {
                        items[index] = item.copy(checked = checked)
                        saveItems()
                        renderItems()
                    }
                }
            }
            row.addView(check)
            row.addView(TextView(this).apply {
                text = item.text
                textSize = 18f
                setTextColor(if (item.checked) Color.GRAY else Color.rgb(40, 45, 41))
                paintFlags = if (item.checked) paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
                    else paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(4), dp(8), dp(4), dp(8))
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(ImageButton(this).apply {
                setImageResource(android.R.drawable.ic_menu_delete)
                contentDescription = "Usuń ${item.text}"
                setBackgroundColor(Color.TRANSPARENT)
                setOnClickListener {
                    items.removeAll { it.id == item.id }
                    saveItems()
                    renderItems()
                }
            }, LinearLayout.LayoutParams(dp(44), dp(44)))
            val outer = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, dp(3), 0, dp(3))
                addView(row)
                addView(View(this@MainActivity).apply {
                    setBackgroundColor(Color.rgb(225, 225, 218))
                }, LinearLayout.LayoutParams(-1, dp(1)))
            }
            listBox.addView(outer)
        }
    }

    private fun saveItems() {
        val array = JSONArray()
        items.forEach {
            array.put(JSONObject().put("id", it.id).put("text", it.text).put("checked", it.checked))
        }
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_ITEMS, array.toString()).apply()
    }

    private fun loadItems() {
        val raw = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_ITEMS, "[]") ?: "[]"
        try {
            val array = JSONArray(raw)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                items.add(ShoppingItem(
                    obj.optString("id", UUID.randomUUID().toString()),
                    obj.optString("text", ""),
                    obj.optBoolean("checked", false)
                ))
            }
        } catch (_: Exception) { }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::recognizer.isInitialized) recognizer.close()
    }
}

/** Simple paper-like ink surface. Captures stylus and finger strokes as ML Kit Ink. */
class InkPad(context: Context) : View(context) {
    private val strokes = mutableListOf<Ink.Stroke>()
    private var builder: Ink.Stroke.Builder? = null
    private val currentPoints = mutableListOf<Ink.Point>()
    private val path = Path()
    private val paths = mutableListOf<Path>()
    private val inkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(35, 53, 47)
        style = Paint.Style.STROKE
        strokeWidth = 4f
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val paperPaint = Paint().apply { color = Color.WHITE }
    private val linePaint = Paint().apply {
        color = Color.rgb(224, 231, 226)
        strokeWidth = 1f
    }

    init { setBackgroundColor(Color.WHITE) }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paperPaint)
        var y = 32f
        while (y < height) {
            canvas.drawLine(0f, y, width.toFloat(), y, linePaint)
            y += 32f
        }
        paths.forEach { canvas.drawPath(it, inkPaint) }
        canvas.drawPath(path, inkPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                builder = Ink.Stroke.builder()
                currentPoints.clear()
                path.reset()
                path.moveTo(event.x, event.y)
                addPoint(event)
                invalidate()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until event.historySize) {
                    addPoint(event, i)
                    path.lineTo(event.getHistoricalX(i), event.getHistoricalY(i))
                }
                addPoint(event)
                path.lineTo(event.x, event.y)
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                addPoint(event)
                builder?.addPoint(Ink.Point.create(event.x, event.y, event.eventTime))
                builder?.build()?.let { strokes.add(it) }
                paths.add(Path(path))
                builder = null
                path.reset()
                invalidate()
                return true
            }
        }
        return true
    }

    private fun addPoint(event: MotionEvent, historyIndex: Int? = null) {
        val x = historyIndex?.let { event.getHistoricalX(it) } ?: event.x
        val y = historyIndex?.let { event.getHistoricalY(it) } ?: event.y
        val t = historyIndex?.let { event.getHistoricalEventTime(it) } ?: event.eventTime
        builder?.addPoint(Ink.Point.create(x, y, t))
    }

    fun isEmpty() = strokes.isEmpty()

    fun getInk(): Ink {
        val builder = Ink.builder()
        strokes.forEach { builder.addStroke(it) }
        return builder.build()
    }

    fun clear() {
        strokes.clear()
        paths.clear()
        path.reset()
        invalidate()
    }
}
